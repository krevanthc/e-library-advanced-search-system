package in.co.library.model;

public enum Role {
    User, Admin
}
