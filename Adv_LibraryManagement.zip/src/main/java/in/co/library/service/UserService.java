package in.co.library.service;

import java.sql.SQLException;

@FunctionalInterface
public interface UserService {
    void compile() throws SQLException, ClassNotFoundException;
}
