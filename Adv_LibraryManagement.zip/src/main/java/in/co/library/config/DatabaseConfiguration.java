package in.co.library.config;

import lombok.Getter;

@Getter
public class DatabaseConfiguration {
    private final String DB_URL = "jdbc:mysql://localhost:3306/libManagementDB";
    private final String DB_USERNAME = "root";
    private final String DB_PASSWORD = "root";
    private final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
}